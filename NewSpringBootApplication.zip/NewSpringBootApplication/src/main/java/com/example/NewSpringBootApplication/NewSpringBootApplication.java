package com.example.NewSpringBootApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewSpringBootApplication.class, args);
	}

}
